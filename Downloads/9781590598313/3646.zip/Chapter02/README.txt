This file is a part of 1590598318-1.zip containing example source code for the 
Foundations of Qt Development book available from APress (ISBN 1590598318).

These are the examples for chapter 2 - Rapid Application Development Using Qt

addressbook

  This is the only example of the chapter, covering all listings.
