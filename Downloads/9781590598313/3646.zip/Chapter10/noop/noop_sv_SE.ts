<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="sv">
<context>
    <name></name>
    <message>
        <location filename="main.cpp" line="19"/>
        <source>This is a very special string.</source>
        <translation>Detta är en väldigt speciell sträng.</translation>
    </message>
    <message>
        <location filename="main.cpp" line="20"/>
        <source>And this is just as special.</source>
        <translation>Och denna är precis lika speciell.</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="main.cpp" line="15"/>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="main.cpp" line="16"/>
        <source>Title</source>
        <translation>Titel</translation>
    </message>
    <message>
        <location filename="main.cpp" line="17"/>
        <source>Publisher</source>
        <translation>Utgivare</translation>
    </message>
</context>
</TS>
