<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="sw">
<context>
    <name>DynDialog</name>
    <message>
        <location filename="dyndialog.cpp" line="59"/>
        <source>Languages</source>
        <translation>Språk</translation>
    </message>
    <message>
        <location filename="dyndialog.cpp" line="61"/>
        <source>English</source>
        <translation>Engelska</translation>
    </message>
    <message>
        <location filename="dyndialog.cpp" line="62"/>
        <source>Swedish</source>
        <translation>Svenska</translation>
    </message>
</context>
</TS>
