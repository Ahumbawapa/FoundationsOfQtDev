<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="en">
<context>
    <name>DynDialog</name>
    <message>
        <location filename="dyndialog.cpp" line="59"/>
        <source>Languages</source>
        <translation>Languages</translation>
    </message>
    <message>
        <location filename="dyndialog.cpp" line="61"/>
        <source>English</source>
        <translation>English</translation>
    </message>
    <message>
        <location filename="dyndialog.cpp" line="62"/>
        <source>Swedish</source>
        <translation>Swedish</translation>
    </message>
</context>
</TS>
