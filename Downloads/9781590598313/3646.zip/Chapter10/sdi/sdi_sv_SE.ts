<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="sv_SE">
<context>
    <name>SdiWindow</name>
    <message>
        <location filename="sdiwindow.cpp" line="254"/>
        <source>%1[*] - %2</source>
        <translation>%1[*] - %2</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="19"/>
        <source>unnamed</source>
        <translation>namnlös</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="254"/>
        <source>SDI</source>
        <translation>SDI</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="29"/>
        <source>Done</source>
        <translation>Klar</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="47"/>
        <source>About SDI</source>
        <translation>Om SDI</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="47"/>
        <source>A single document interface application.</source>
        <translation>En applikation med enkeldokumentgränssnitt.</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="52"/>
        <source>&amp;New</source>
        <translation>&amp;Ny</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="53"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="54"/>
        <source>Create a new document</source>
        <translation>Skapa ett nytt dokument</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="57"/>
        <source>&amp;Open</source>
        <translation>&amp;Öppna</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="58"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="59"/>
        <source>Open a document</source>
        <translation>Öppna ett dokument</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="62"/>
        <source>&amp;Save</source>
        <translation>&amp;Spara</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="63"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="64"/>
        <source>Save the document</source>
        <translation>Spara dokumentet</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="67"/>
        <source>Save &amp;As</source>
        <translation>Spara so&amp;m</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="68"/>
        <source>Save the document as</source>
        <translation>Spara dokumentet som</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="71"/>
        <source>&amp;Close</source>
        <translation>S&amp;täng</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="72"/>
        <source>Ctrl+W</source>
        <translation>Ctrl+W</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="73"/>
        <source>Close this document</source>
        <translation>Stäng detta dokument</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="76"/>
        <source>E&amp;xit</source>
        <translation>A&amp;vsluta</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="77"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="78"/>
        <source>Quit the application</source>
        <translation>Avslutar applikationen</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="82"/>
        <source>Cu&amp;t</source>
        <translation>K&amp;lipp</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="83"/>
        <source>Ctrl+X</source>
        <translation>Ctrl+X</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="84"/>
        <source>Cut</source>
        <translation>Klipp</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="89"/>
        <source>&amp;Copy</source>
        <translation>&amp;Kopiera</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="90"/>
        <source>Ctrl+C</source>
        <translation>Ctrl+C</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="91"/>
        <source>Copy</source>
        <translation>Kopiera</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="97"/>
        <source>&amp;Paste</source>
        <translation>Kl&amp;istra in</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="98"/>
        <source>Ctrl+V</source>
        <translation>Ctrl+V</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="99"/>
        <source>Paste</source>
        <translation>Klista in</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="103"/>
        <source>&amp;About</source>
        <translation>&amp;Om</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="104"/>
        <source>About this application</source>
        <translation>Om denna applikation</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="107"/>
        <source>About &amp;Qt</source>
        <translation>Om &amp;Qt</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="108"/>
        <source>About the Qt toolkit</source>
        <translation>Om Qt verktyget</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="116"/>
        <source>&amp;File</source>
        <translation>&amp;Arkiv</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="127"/>
        <source>&amp;Edit</source>
        <translation>&amp;Redigera</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="132"/>
        <source>&amp;Help</source>
        <translation>&amp;Hjälp</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="141"/>
        <source>File</source>
        <translation>Arkiv</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="144"/>
        <source>Edit</source>
        <translation>Redigera</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="159"/>
        <source>The document has unsaved changes.
Do you want to save it before it is closed?</source>
        <translation>Dokumentets ändringar är inte sparade.
Vill du spara ändringarna innan dokumentet stängs?</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="210"/>
        <source>Save As</source>
        <translation>Spara som</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="224"/>
        <source>Failed to save file.</source>
        <translation>Misslyckades med att spara dokumentet.</translation>
    </message>
    <message>
        <location filename="sdiwindow.cpp" line="245"/>
        <source>Failed to open file.</source>
        <translation>Misslyckades med att öppna dokumentet.</translation>
    </message>
</context>
</TS>
