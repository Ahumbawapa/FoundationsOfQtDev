This file is a part of 1590598318-1.zip containing example source code for the 
Foundations of Qt Development book available from APress (ISBN 1590598318).

These are the examples for chapter 4 - The Main Window

sdi

  Listings 4-1, 4-2, 4-3, 4-4, 4-5
  
  A simple text editor with a single document interface (SDI).

 
mdi

  Listings 4-6, 4-7, 4-8, 4-9, 4-10, 4-11, 4-12, 4-13, 4-14, 4-15

  A simple text editor with a multiple document interface (MDI).


resources

  Listings 4-16, 4-17, 4-18
  
  Example resource files.
  

dock

  Listings 4-19, 4-20, 4-21, 4-22, 4-23
  
  Shows how a dock widgets can be added to a QMainWindow.

