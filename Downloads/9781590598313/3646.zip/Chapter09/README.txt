This file is a part of 1590598318-1.zip containing example source code for the 
Foundations of Qt Development book available from APress (ISBN 1590598318).

These are the examples for chapter 9 - Providing Help

tooltips

  Listings 9-1, 9-2, 9-3, 9-4
  
  Shows tooltips with different formatting and embedded images.


tooltipzones

  Listing 9-5
  
  Shows how to provide different tooltips for different parts of a single 
  widget.


whatsthis

  Not shown in any Listings, but Figures 9-6 and 9-7.
  
  Shows what's this help with different formatting and embedded images.


whatsthislink

  Listings 9-6, 9-7, 9-8, 9-9
  
  Shows how to provide clickable links in your what's this help boxes.


statusbar

  Listings 9-10
  
  Shows how to add different widgets to a status bar.


wizard

  Listings 9-11, 9-12, 9-13, 9-14, 9-15
  
  Shows how to implement a wizard dialog.


assistant

  Listings 9-16, 9-17
  
  Shows how to use Qt Assistant as a help browser.