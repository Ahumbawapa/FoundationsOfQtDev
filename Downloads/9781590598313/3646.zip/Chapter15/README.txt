This file is a part of 1590598318-1.zip containing example source code for the 
Foundations of Qt Development book available from APress (ISBN 1590598318).

These are the examples for chapter 15 - Building Qt Projects

qmake/basics

  Listing 15-1
  
  A basic QMake project.


qmake/complex

  Listing 15-5, 15-6, 15-7
  
  A complex QMake project consisting of a lib and an application.


cmake/basics

  Listing 15-8
  
  A basic CMake project.


cmake/complex

  Listings 15-12, 15-13, 15-14

  A complex CMake project consisting of a lib and an application.